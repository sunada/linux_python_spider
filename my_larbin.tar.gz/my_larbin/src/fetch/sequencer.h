// Larbin
// Sebastien Ailleret
// 15-11-99 -> 15-11-99

#ifndef SEQUENCER_H
#define SEQUENCER_H

/** only for debugging, handle with care */
extern uint space;

/** Call the sequencer */
void sequencer ();

#endif
