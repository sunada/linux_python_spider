// Larbin
// Sebastien Ailleret
// 09-12-01 -> 09-12-01

void initSpecific () { }

#define constrSpec() ((void) 0)
#define newSpec() ((void) 0)
#define pipeSpec() 0
#define endOfInput() 0
#define getContent() contentStart
#define getSize() (buffer + pos - contentStart)
#define destructSpec() ((void) 0)
