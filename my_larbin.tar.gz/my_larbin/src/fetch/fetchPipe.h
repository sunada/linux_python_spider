// Larbin
// Sebastien Ailleret
// 15-11-99 -> 22-07-01

#ifndef FETCHPIPE_H
#define FETCHPIPE_H

void checkTimeout ();

void checkAll ();

#endif // FETCH_H
